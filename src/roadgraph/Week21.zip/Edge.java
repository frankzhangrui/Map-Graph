package roadgraph;

import geography.GeographicPoint;

public class Edge {
		
		public String roadName;
		public String roadType;
		public double distance;
		public GeographicPoint start;
		public GeographicPoint end;
		
		public Edge(GeographicPoint start, GeographicPoint end, String roadName, String roadType, double distance) {
			this.start = start;
			this.end = end;
			this.roadName = roadName;
			this.roadType = roadType;
			this.distance = distance;
		}
		
}
